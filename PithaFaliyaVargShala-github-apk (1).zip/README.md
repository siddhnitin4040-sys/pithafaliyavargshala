# પીઠા ફળિયા વર્ગ શાળા — GitHub થી APK

આ રિપોઝિટરી GitHub Actions વડે Android APK બનાવે છે.

## ૧) નવી GitHub રિપો બનાવો
1. github.com → **New repository**
2. નામ: `PithaFaliyaVargShala`
3. Public રાખો
4. આ ઝિપની અંદરની બધી ફાઈલો અપલોડ કરો (`.github` ફોલ્ડર સાથે)

## ૨) એપની વેબ લિંક મૂકો
ફોનની એપ વેબ એપ ખોલે છે. Grokમાં **Publish** કરીને મળેલી HTTPS લિંક જોઈએ.

**રીત A — Secret (સારી):**
1. Repo → **Settings → Secrets and variables → Actions**
2. **New repository secret**
3. Name: `APP_URL`
4. Value: `https://your-published-app-link`

**રીત B — ફાઈલમાં:**
`app/src/main/res/values/strings.xml` ખોલો અને `https://example.com` બદલો.

## ૩) APK બને
1. **Actions** ટેબ ખોલો
2. **Build APK** વર્કફ્લો ચાલે (અથવા **Run workflow**)
3. લીલું ટિક આવે પછી **PithaFaliyaVargShala** આર્ટિફેક્ટ ડાઉનલોડ કરો
4. અનઝિપ કરો → `app-debug.apk`
5. ફોન પર કોપી કરીને ઇન્સ્ટોલ કરો (Unknown sources ચાલુ)

ફોન પર **Gujarati / Hindi TTS** હોય તો ઉચ્ચાર Androidના સ્પીકરથી થાય છે.
