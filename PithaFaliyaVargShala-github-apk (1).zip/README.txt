પીઠા ફળિયા વર્ગ શાળા — Android Studio પ્રોજેક્ટ
================================================

આ ફોલ્ડર Android Studioમાં ખોલો. એપ WebViewથી વેબ એપ ચલાવે છે.

૧) Grokમાં આ વેબ એપ Publish કરો અને HTTPS લિંક નકલ કરો.

૨) આ ફાઈલ ખોલો:
   app/src/main/res/values/strings.xml

   <string name="app_url">https://example.com</string>
   ને તમારી Publish લિંકથી બદલો.

૩) Android Studio:
   File → Open → આ ફોલ્ડર પસંદ કરો
   Gradle Sync થાય ત્યાં રાહ જુઓ
   (gradle-wrapper.jar ન હોય તો Studio પૂછે — "OK / Use Gradle Wrapper")

૪) ફોન USBથી જોડો (Developer options + USB debugging)
   અથવા એમ્યુલેટર ચાલુ કરો

૫) Run (લીલું ત્રિકોણ) દબાવો

અવાજ: ફોનનો મીડિયા વોલ્યુમ વધારો. ઇન્ટરનેટ જરૂરી છે.
પેકેજ: com.pithafaliya.vargshala
